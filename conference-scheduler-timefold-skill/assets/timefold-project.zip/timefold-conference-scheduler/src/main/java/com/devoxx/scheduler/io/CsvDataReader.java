package com.devoxx.scheduler.io;

import com.devoxx.scheduler.domain.*;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.exceptions.CsvValidationException;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Reads conference data from CSV files.
 * 
 * Expected formats:
 * 
 * Schedule CSV (single-day): "from hour";"to hour";"session type";"room name"
 * Schedule CSV (multi-day):  "day";"from hour";"to hour";"session type";"room name"
 * 
 * Talks CSV: "Talk ID";"Talk Title";"Audience Level";"Talk Summary";"Track Name";
 *            "Speaker Availability days";"Available from";"Available to";"Speaker names"
 */
public class CsvDataReader {

    private static final char SEPARATOR = ';';

    // Detected day names for availability parsing
    private List<String> detectedDayNames = new ArrayList<>();

    /**
     * Read the complete conference schedule problem from CSV files.
     */
    public ConferenceSchedule readProblem(Path schedulePath, Path talksPath) throws IOException, CsvValidationException {
        List<Timeslot> timeslots = readSchedule(schedulePath);
        List<Room> rooms = extractRooms(schedulePath);
        List<Talk> talks = readTalks(talksPath);
        
        // Apply speaker availability if multi-day
        if (!detectedDayNames.isEmpty()) {
            for (Talk talk : talks) {
                if (talk.getAvailableDaysRaw() != null && !talk.getAvailableDaysRaw().isBlank()) {
                    talk.parseAvailableDays(talk.getAvailableDaysRaw(), detectedDayNames);
                }
            }
        }
        
        return new ConferenceSchedule(timeslots, rooms, talks);
    }

    /**
     * Read unique timeslots from schedule CSV.
     * Auto-detects single-day vs multi-day format based on header.
     */
    public List<Timeslot> readSchedule(Path path) throws IOException, CsvValidationException {
        Set<Timeslot> timeslotSet = new LinkedHashSet<>();
        Map<String, Integer> dayNameToIndex = new LinkedHashMap<>();
        
        try (CSVReader reader = createReader(path)) {
            String[] header = reader.readNext();
            boolean hasDay = header != null && header.length > 0 && 
                cleanValue(header[0]).toLowerCase().contains("day");
            
            int dayCol = hasDay ? 0 : -1;
            int fromCol = hasDay ? 1 : 0;
            int toCol = hasDay ? 2 : 1;
            
            String[] line;
            while ((line = reader.readNext()) != null) {
                if (line.length < (hasDay ? 3 : 2)) continue;
                
                String dayName = null;
                int dayIndex = 0;
                
                if (hasDay) {
                    dayName = cleanValue(line[dayCol]);
                    if (!dayNameToIndex.containsKey(dayName)) {
                        dayNameToIndex.put(dayName, dayNameToIndex.size());
                    }
                    dayIndex = dayNameToIndex.get(dayName);
                }
                
                String fromHour = cleanValue(line[fromCol]);
                String toHour = cleanValue(line[toCol]);
                
                timeslotSet.add(Timeslot.fromCsv(fromHour, toHour, dayIndex, dayName));
            }
        }
        
        // Store detected day names for availability parsing
        detectedDayNames = new ArrayList<>(dayNameToIndex.keySet());
        
        List<Timeslot> timeslots = new ArrayList<>(timeslotSet);
        Collections.sort(timeslots);
        return timeslots;
    }

    /**
     * Extract unique rooms from schedule CSV.
     */
    public List<Room> extractRooms(Path path) throws IOException, CsvValidationException {
        Set<String> roomNames = new LinkedHashSet<>();
        
        try (CSVReader reader = createReader(path)) {
            String[] header = reader.readNext();
            boolean hasDay = header != null && header.length > 0 && 
                cleanValue(header[0]).toLowerCase().contains("day");
            
            int roomCol = hasDay ? 4 : 3;
            
            String[] line;
            while ((line = reader.readNext()) != null) {
                if (line.length > roomCol) {
                    String roomName = cleanValue(line[roomCol]);
                    if (!roomName.isBlank()) {
                        roomNames.add(roomName);
                    }
                }
            }
        }
        
        return roomNames.stream()
            .map(Room::new)
            .sorted(Comparator.comparing(Room::getName))
            .collect(Collectors.toList());
    }

    /**
     * Read talks from CSV file.
     */
    public List<Talk> readTalks(Path path) throws IOException, CsvValidationException {
        List<Talk> talks = new ArrayList<>();
        
        try (CSVReader reader = createReader(path)) {
            reader.skip(1); // Skip header
            String[] line;
            while ((line = reader.readNext()) != null) {
                if (line.length >= 9) {
                    Talk talk = new Talk(
                        cleanValue(line[0]),                          // ID
                        cleanValue(line[1]),                          // Title
                        cleanValue(line[3]),                          // Summary (index 3)
                        cleanValue(line[4]),                          // Track Name
                        AudienceLevel.fromString(cleanValue(line[2])), // Level
                        cleanValue(line[8])                           // Speaker names
                    );
                    // Store availability days raw string for later parsing
                    talk.setAvailableDaysRaw(cleanValue(line[5]));
                    talks.add(talk);
                }
            }
        }
        
        return talks;
    }

    /**
     * Get the detected day names from the schedule.
     */
    public List<String> getDetectedDayNames() {
        return detectedDayNames;
    }

    /**
     * Check if the loaded schedule is multi-day.
     */
    public boolean isMultiDay() {
        return detectedDayNames.size() > 1;
    }

    /**
     * Update talks with AI-computed flow order.
     * The flowOrders map contains: trackName -> list of talk IDs in optimal order
     */
    public void applyFlowOrder(List<Talk> talks, Map<String, List<String>> flowOrders) {
        for (Map.Entry<String, List<String>> entry : flowOrders.entrySet()) {
            String track = entry.getKey();
            List<String> orderedIds = entry.getValue();
            
            for (int i = 0; i < orderedIds.size(); i++) {
                final int order = i + 1;
                final String talkId = orderedIds.get(i);
                talks.stream()
                    .filter(t -> t.getId().equals(talkId) && t.getTrackName().equals(track))
                    .findFirst()
                    .ifPresent(t -> t.setFlowOrder(order));
            }
        }
    }

    private CSVReader createReader(Path path) throws IOException {
        return new CSVReaderBuilder(Files.newBufferedReader(path))
            .withCSVParser(new CSVParserBuilder()
                .withSeparator(SEPARATOR)
                .withQuoteChar('"')
                .build())
            .build();
    }

    private String cleanValue(String value) {
        if (value == null) return "";
        return value.trim().replaceAll("^\"|\"$", "");
    }
}
