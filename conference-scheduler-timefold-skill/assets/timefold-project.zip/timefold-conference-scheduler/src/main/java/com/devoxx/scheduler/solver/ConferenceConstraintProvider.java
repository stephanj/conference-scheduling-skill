package com.devoxx.scheduler.solver;

import ai.timefold.solver.core.api.score.buildin.hardsoft.HardSoftScore;
import ai.timefold.solver.core.api.score.stream.Constraint;
import ai.timefold.solver.core.api.score.stream.ConstraintFactory;
import ai.timefold.solver.core.api.score.stream.ConstraintProvider;
import ai.timefold.solver.core.api.score.stream.Joiners;
import com.devoxx.scheduler.domain.Talk;

/**
 * Defines all scheduling constraints using TimeFold's Constraint Streams API.
 * 
 * HARD CONSTRAINTS (must be satisfied):
 * - Speaker conflict: Same speaker can't be in two rooms at the same time
 * - Room conflict: Two talks can't be in the same room at the same time
 * - Track conflict: Same track can't have talks in different rooms at the same time
 * - Speaker availability: Speaker must be available on the scheduled day
 * 
 * SOFT CONSTRAINTS (optimization goals):
 * - Educational flow: Talks should progress from beginner to advanced within a track
 * - Flow order: Respect AI-computed flow order for talks within same track
 * - Track room consistency: Keep same track in same room
 * - Track day consistency: Keep same track on same day when possible (multi-day)
 */
public class ConferenceConstraintProvider implements ConstraintProvider {

    @Override
    public Constraint[] defineConstraints(ConstraintFactory constraintFactory) {
        return new Constraint[] {
            // Hard constraints
            speakerConflict(constraintFactory),
            roomConflict(constraintFactory),
            trackConflict(constraintFactory),
            speakerAvailability(constraintFactory),
            
            // Soft constraints
            educationalFlowByLevel(constraintFactory),
            educationalFlowByOrder(constraintFactory),
            trackRoomConsistency(constraintFactory),
            trackDayConsistency(constraintFactory)
        };
    }

    // ==================== HARD CONSTRAINTS ====================

    /**
     * A speaker can't give two talks at the same time.
     */
    Constraint speakerConflict(ConstraintFactory constraintFactory) {
        return constraintFactory
            .forEachUniquePair(Talk.class,
                Joiners.equal(Talk::getTimeslot),
                Joiners.filtering((talk1, talk2) -> hasSpeakerOverlap(talk1, talk2)))
            .penalize(HardSoftScore.ONE_HARD)
            .asConstraint("Speaker conflict");
    }

    /**
     * Two talks can't be in the same room at the same time.
     */
    Constraint roomConflict(ConstraintFactory constraintFactory) {
        return constraintFactory
            .forEachUniquePair(Talk.class,
                Joiners.equal(Talk::getTimeslot),
                Joiners.equal(Talk::getRoom))
            .penalize(HardSoftScore.ONE_HARD)
            .asConstraint("Room conflict");
    }

    /**
     * Talks of the same track should not be scheduled at the same time.
     * This is a HIGH constraint from the requirements.
     */
    Constraint trackConflict(ConstraintFactory constraintFactory) {
        return constraintFactory
            .forEachUniquePair(Talk.class,
                Joiners.equal(Talk::getTimeslot),
                Joiners.equal(Talk::getTrackName))
            .penalize(HardSoftScore.ONE_HARD)
            .asConstraint("Track conflict - same track at same time");
    }

    /**
     * Speaker must be available on the day their talk is scheduled.
     * Only applies when speaker has availability restrictions.
     */
    Constraint speakerAvailability(ConstraintFactory constraintFactory) {
        return constraintFactory
            .forEach(Talk.class)
            .filter(talk -> talk.getTimeslot() != null)
            .filter(talk -> !talk.getAvailableDays().isEmpty()) // Has restrictions
            .filter(talk -> !talk.isAvailableForTimeslot())     // Not available
            .penalize(HardSoftScore.ONE_HARD)
            .asConstraint("Speaker availability");
    }

    // ==================== SOFT CONSTRAINTS ====================

    /**
     * Within a track, beginner talks should come before advanced talks.
     * Penalize when an advanced talk comes before a beginner talk in the same track.
     * For multi-day: only compare talks on the same day.
     */
    Constraint educationalFlowByLevel(ConstraintFactory constraintFactory) {
        return constraintFactory
            .forEachUniquePair(Talk.class,
                Joiners.equal(Talk::getTrackName))
            .filter((talk1, talk2) -> {
                if (talk1.getTimeslot() == null || talk2.getTimeslot() == null) {
                    return false;
                }
                // Only compare within same day for multi-day conferences
                if (!talk1.getTimeslot().isSameDay(talk2.getTimeslot())) {
                    return false;
                }
                // Check if higher level talk comes before lower level talk
                int timeCompare = talk1.getTimeslot().compareTo(talk2.getTimeslot());
                int levelCompare = talk1.getAudienceLevel().getDefaultFlowOrder() 
                                 - talk2.getAudienceLevel().getDefaultFlowOrder();
                // Penalize if talk1 is later but has lower level (should be earlier)
                // Or if talk1 is earlier but has higher level (should be later)
                return (timeCompare > 0 && levelCompare < 0) || (timeCompare < 0 && levelCompare > 0);
            })
            .penalize(HardSoftScore.ONE_SOFT, (talk1, talk2) -> 
                Math.abs(talk1.getAudienceLevel().getDefaultFlowOrder() 
                       - talk2.getAudienceLevel().getDefaultFlowOrder()))
            .asConstraint("Educational flow - level progression");
    }

    /**
     * Respect the AI-computed flow order for talks within the same track.
     * Lower flow order should come before higher flow order.
     * For multi-day: only compare talks on the same day.
     */
    Constraint educationalFlowByOrder(ConstraintFactory constraintFactory) {
        return constraintFactory
            .forEachUniquePair(Talk.class,
                Joiners.equal(Talk::getTrackName))
            .filter((talk1, talk2) -> {
                if (talk1.getTimeslot() == null || talk2.getTimeslot() == null) {
                    return false;
                }
                // Only compare within same day for multi-day conferences
                if (!talk1.getTimeslot().isSameDay(talk2.getTimeslot())) {
                    return false;
                }
                int timeCompare = talk1.getTimeslot().compareTo(talk2.getTimeslot());
                int orderCompare = talk1.getFlowOrder() - talk2.getFlowOrder();
                // Penalize if order doesn't match time
                return (timeCompare > 0 && orderCompare < 0) || (timeCompare < 0 && orderCompare > 0);
            })
            .penalize(HardSoftScore.ONE_SOFT, (talk1, talk2) -> 
                Math.abs(talk1.getFlowOrder() - talk2.getFlowOrder()))
            .asConstraint("Educational flow - summary-based order");
    }

    /**
     * Try to keep same track in same room for consistency.
     * Attendees prefer following a track in the same room.
     */
    Constraint trackRoomConsistency(ConstraintFactory constraintFactory) {
        return constraintFactory
            .forEachUniquePair(Talk.class,
                Joiners.equal(Talk::getTrackName))
            .filter((talk1, talk2) -> 
                talk1.getRoom() != null && talk2.getRoom() != null 
                && talk1.getTimeslot() != null && talk2.getTimeslot() != null
                && talk1.getTimeslot().isSameDay(talk2.getTimeslot()) // Same day only
                && !talk1.getRoom().equals(talk2.getRoom()))
            .penalize(HardSoftScore.ofSoft(1))
            .asConstraint("Track room consistency");
    }

    /**
     * For multi-day conferences, try to keep talks of the same track on the same day.
     * This makes it easier for attendees to follow a track.
     */
    Constraint trackDayConsistency(ConstraintFactory constraintFactory) {
        return constraintFactory
            .forEachUniquePair(Talk.class,
                Joiners.equal(Talk::getTrackName))
            .filter((talk1, talk2) -> 
                talk1.getTimeslot() != null && talk2.getTimeslot() != null
                && !talk1.getTimeslot().isSameDay(talk2.getTimeslot()))
            .penalize(HardSoftScore.ofSoft(2)) // Slightly higher than room consistency
            .asConstraint("Track day consistency");
    }

    // ==================== HELPER METHODS ====================

    /**
     * Check if two talks share any speaker.
     * Handles comma-separated speaker names.
     */
    private boolean hasSpeakerOverlap(Talk talk1, Talk talk2) {
        if (talk1.getSpeakerNames() == null || talk2.getSpeakerNames() == null) {
            return false;
        }
        String[] speakers1 = talk1.getSpeakerNames().split(",");
        String[] speakers2 = talk2.getSpeakerNames().split(",");
        
        for (String s1 : speakers1) {
            for (String s2 : speakers2) {
                if (s1.trim().equalsIgnoreCase(s2.trim())) {
                    return true;
                }
            }
        }
        return false;
    }
}
