package com.devoxx.scheduler.domain;

/**
 * Audience level for a talk, affects educational flow ordering.
 */
public enum AudienceLevel {
    BEGINNER(1),
    INTERMEDIATE(2),
    ADVANCED(3);

    private final int defaultFlowOrder;

    AudienceLevel(int defaultFlowOrder) {
        this.defaultFlowOrder = defaultFlowOrder;
    }

    /**
     * Default flow order based on level.
     * Beginner talks should generally come before advanced talks.
     */
    public int getDefaultFlowOrder() {
        return defaultFlowOrder;
    }

    public static AudienceLevel fromString(String level) {
        if (level == null || level.isBlank()) {
            return INTERMEDIATE;
        }
        return switch (level.toUpperCase().trim()) {
            case "BEGINNER", "BEGINER" -> BEGINNER;
            case "ADVANCED" -> ADVANCED;
            default -> INTERMEDIATE;
        };
    }
}
