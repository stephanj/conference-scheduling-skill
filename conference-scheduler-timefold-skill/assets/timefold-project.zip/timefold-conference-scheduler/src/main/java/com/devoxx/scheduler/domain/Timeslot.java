package com.devoxx.scheduler.domain;

import ai.timefold.solver.core.api.domain.lookup.PlanningId;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 * A time slot during which talks can be scheduled.
 * Supports multi-day conferences with day index or date.
 */
public class Timeslot implements Comparable<Timeslot> {

    private static final DateTimeFormatter TIME_FORMAT = DateTimeFormatter.ofPattern("HH:mm");
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    @PlanningId
    private String id;
    private LocalTime startTime;
    private LocalTime endTime;
    private int dayIndex; // 0-based day number (0 = day 1)
    private String dayName; // Optional: "Monday", "Day 1", "2024-03-15", etc.
    private LocalDate date; // Optional: actual date

    public Timeslot() {
    }

    public Timeslot(String id, LocalTime startTime, LocalTime endTime) {
        this(id, startTime, endTime, 0, null, null);
    }

    public Timeslot(String id, LocalTime startTime, LocalTime endTime, int dayIndex) {
        this(id, startTime, endTime, dayIndex, null, null);
    }

    public Timeslot(String id, LocalTime startTime, LocalTime endTime, int dayIndex, String dayName, LocalDate date) {
        this.id = id;
        this.startTime = startTime;
        this.endTime = endTime;
        this.dayIndex = dayIndex;
        this.dayName = dayName;
        this.date = date;
    }

    /**
     * Create timeslot from CSV without day info (single-day conference).
     */
    public static Timeslot fromCsv(String fromHour, String toHour) {
        return fromCsv(fromHour, toHour, 0, null);
    }

    /**
     * Create timeslot from CSV with day index.
     */
    public static Timeslot fromCsv(String fromHour, String toHour, int dayIndex, String dayName) {
        LocalTime start = LocalTime.parse(fromHour.trim(), TIME_FORMAT);
        LocalTime end = LocalTime.parse(toHour.trim(), TIME_FORMAT);
        
        String dayPrefix = dayIndex > 0 ? "D" + (dayIndex + 1) + "-" : "";
        String id = dayPrefix + fromHour.trim() + "-" + toHour.trim();
        
        LocalDate date = null;
        if (dayName != null && dayName.matches("\\d{4}-\\d{2}-\\d{2}")) {
            date = LocalDate.parse(dayName, DATE_FORMAT);
        }
        
        return new Timeslot(id, start, end, dayIndex, dayName, date);
    }

    /**
     * Returns the slot index for ordering purposes.
     * Days are separated by 10000 to ensure proper ordering.
     */
    public int getSlotIndex() {
        return dayIndex * 10000 + startTime.getHour() * 60 + startTime.getMinute();
    }

    /**
     * Check if this timeslot is on the same day as another.
     */
    public boolean isSameDay(Timeslot other) {
        if (other == null) return false;
        return this.dayIndex == other.dayIndex;
    }

    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public LocalTime getStartTime() { return startTime; }
    public void setStartTime(LocalTime startTime) { this.startTime = startTime; }

    public LocalTime getEndTime() { return endTime; }
    public void setEndTime(LocalTime endTime) { this.endTime = endTime; }

    public int getDayIndex() { return dayIndex; }
    public void setDayIndex(int dayIndex) { this.dayIndex = dayIndex; }

    public String getDayName() { return dayName; }
    public void setDayName(String dayName) { this.dayName = dayName; }

    public LocalDate getDate() { return date; }
    public void setDate(LocalDate date) { this.date = date; }

    public String getFromHour() {
        return startTime.format(TIME_FORMAT);
    }

    public String getToHour() {
        return endTime.format(TIME_FORMAT);
    }

    /**
     * Get display name for the day (e.g., "Day 1", "Monday", or date).
     */
    public String getDayDisplay() {
        if (dayName != null && !dayName.isBlank()) {
            return dayName;
        }
        if (date != null) {
            return date.format(DATE_FORMAT);
        }
        return "Day " + (dayIndex + 1);
    }

    @Override
    public int compareTo(Timeslot other) {
        int dayCompare = Integer.compare(this.dayIndex, other.dayIndex);
        if (dayCompare != 0) return dayCompare;
        return this.startTime.compareTo(other.startTime);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Timeslot timeslot = (Timeslot) o;
        return id.equals(timeslot.id);
    }

    @Override
    public int hashCode() {
        return id.hashCode();
    }

    @Override
    public String toString() {
        if (dayIndex > 0 || dayName != null) {
            return getDayDisplay() + " " + startTime.format(TIME_FORMAT) + "-" + endTime.format(TIME_FORMAT);
        }
        return startTime.format(TIME_FORMAT) + "-" + endTime.format(TIME_FORMAT);
    }
}
