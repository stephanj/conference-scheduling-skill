package com.devoxx.scheduler.io;

import com.devoxx.scheduler.domain.ConferenceSchedule;
import com.devoxx.scheduler.domain.Talk;
import com.devoxx.scheduler.domain.Timeslot;

import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.List;

/**
 * Writes the solved schedule to CSV and Markdown formats.
 * Supports both single-day and multi-day conferences.
 */
public class ScheduleWriter {

    private static final String CSV_SEPARATOR = ";";

    /**
     * Write schedule to CSV file.
     * Format (single-day): Talk ID;From;To;Room;Title;Speakers;Level;Track
     * Format (multi-day):  Day;Talk ID;From;To;Room;Title;Speakers;Level;Track
     */
    public void writeCsv(ConferenceSchedule schedule, Path outputPath) throws IOException {
        List<Talk> sortedTalks = getSortedTalks(schedule);
        boolean isMultiDay = isMultiDay(schedule);
        
        try (BufferedWriter writer = Files.newBufferedWriter(outputPath)) {
            // Header
            if (isMultiDay) {
                writer.write("\"Day\";\"Talk ID\";\"From\";\"To\";\"Room\";\"Title\";\"Speakers\";\"Level\";\"Track\"");
            } else {
                writer.write("\"Talk ID\";\"From\";\"To\";\"Room\";\"Title\";\"Speakers\";\"Level\";\"Track\"");
            }
            writer.newLine();
            
            for (Talk talk : sortedTalks) {
                if (talk.getTimeslot() != null && talk.getRoom() != null) {
                    writer.write(formatCsvLine(talk, isMultiDay));
                    writer.newLine();
                }
            }
        }
    }

    /**
     * Write schedule to Markdown format.
     */
    public String toMarkdown(ConferenceSchedule schedule) {
        StringBuilder sb = new StringBuilder();
        sb.append("# Conference Schedule\n\n");
        
        List<Talk> sortedTalks = getSortedTalks(schedule);
        boolean isMultiDay = isMultiDay(schedule);
        
        int currentDay = -1;
        String currentSlot = null;
        
        for (Talk talk : sortedTalks) {
            if (talk.getTimeslot() == null || talk.getRoom() == null) continue;
            
            Timeslot timeslot = talk.getTimeslot();
            
            // Day header for multi-day conferences
            if (isMultiDay && timeslot.getDayIndex() != currentDay) {
                currentDay = timeslot.getDayIndex();
                currentSlot = null; // Reset slot tracking for new day
                sb.append("\n---\n\n");
                sb.append("# ").append(timeslot.getDayDisplay()).append("\n");
            }
            
            // Timeslot header
            String slotId = timeslot.getId();
            if (!slotId.equals(currentSlot)) {
                currentSlot = slotId;
                sb.append("\n## ").append(timeslot.getFromHour())
                  .append(" - ").append(timeslot.getToHour()).append("\n\n");
                sb.append("| Room | Talk ID | Title | Speaker | Level | Track |\n");
                sb.append("|------|---------|-------|---------|-------|-------|\n");
            }
            
            sb.append("| ").append(talk.getRoom().getName())
              .append(" | ").append(talk.getId())
              .append(" | ").append(escapeMarkdown(talk.getTitle()))
              .append(" | ").append(talk.getSpeakerNames())
              .append(" | ").append(talk.getAudienceLevel())
              .append(" | ").append(talk.getTrackName())
              .append(" |\n");
        }
        
        return sb.toString();
    }

    /**
     * Print schedule to console.
     */
    public void printSchedule(ConferenceSchedule schedule) {
        System.out.println("\n" + "=".repeat(100));
        System.out.println("CONFERENCE SCHEDULE");
        System.out.println("=".repeat(100));
        
        List<Talk> sortedTalks = getSortedTalks(schedule);
        boolean isMultiDay = isMultiDay(schedule);
        
        int currentDay = -1;
        String currentSlot = null;
        
        for (Talk talk : sortedTalks) {
            if (talk.getTimeslot() == null || talk.getRoom() == null) continue;
            
            Timeslot timeslot = talk.getTimeslot();
            
            // Day header for multi-day conferences
            if (isMultiDay && timeslot.getDayIndex() != currentDay) {
                currentDay = timeslot.getDayIndex();
                currentSlot = null;
                System.out.println("\n" + "=".repeat(100));
                System.out.println(">>> " + timeslot.getDayDisplay().toUpperCase() + " <<<");
                System.out.println("=".repeat(100));
            }
            
            String slotId = timeslot.getId();
            if (!slotId.equals(currentSlot)) {
                currentSlot = slotId;
                System.out.println("\n" + "-".repeat(100));
                System.out.printf("TIME SLOT: %s - %s%n", 
                    timeslot.getFromHour(), timeslot.getToHour());
                System.out.println("-".repeat(100));
            }
            
            System.out.printf("  %-10s | %5s | %-50s | %-20s | %-12s | %s%n",
                talk.getRoom().getName(),
                talk.getId(),
                truncate(talk.getTitle(), 50),
                truncate(talk.getSpeakerNames(), 20),
                talk.getAudienceLevel(),
                talk.getTrackName());
        }
        
        System.out.println("\n" + "=".repeat(100));
        System.out.println("Score: " + schedule.getScore());
        System.out.println("=".repeat(100));
    }

    /**
     * Check if schedule spans multiple days.
     */
    private boolean isMultiDay(ConferenceSchedule schedule) {
        return schedule.getTimeslots().stream()
            .map(Timeslot::getDayIndex)
            .distinct()
            .count() > 1;
    }

    private List<Talk> getSortedTalks(ConferenceSchedule schedule) {
        return schedule.getTalks().stream()
            .filter(t -> t.getTimeslot() != null && t.getRoom() != null)
            .sorted(Comparator
                .comparing((Talk t) -> t.getTimeslot().getSlotIndex())
                .thenComparing(t -> t.getRoom().getName()))
            .toList();
    }

    private String formatCsvLine(Talk talk, boolean includeDay) {
        if (includeDay) {
            return String.join(CSV_SEPARATOR,
                quote(talk.getTimeslot().getDayDisplay()),
                quote(talk.getId()),
                quote(talk.getTimeslot().getFromHour()),
                quote(talk.getTimeslot().getToHour()),
                quote(talk.getRoom().getName()),
                quote(talk.getTitle()),
                quote(talk.getSpeakerNames()),
                quote(talk.getAudienceLevel().name()),
                quote(talk.getTrackName())
            );
        }
        return String.join(CSV_SEPARATOR,
            quote(talk.getId()),
            quote(talk.getTimeslot().getFromHour()),
            quote(talk.getTimeslot().getToHour()),
            quote(talk.getRoom().getName()),
            quote(talk.getTitle()),
            quote(talk.getSpeakerNames()),
            quote(talk.getAudienceLevel().name()),
            quote(talk.getTrackName())
        );
    }

    private String quote(String value) {
        if (value == null) return "\"\"";
        return "\"" + value.replace("\"", "\"\"") + "\"";
    }

    private String escapeMarkdown(String text) {
        if (text == null) return "";
        return text.replace("|", "\\|");
    }

    private String truncate(String text, int maxLength) {
        if (text == null) return "";
        if (text.length() <= maxLength) return text;
        return text.substring(0, maxLength - 3) + "...";
    }
}
