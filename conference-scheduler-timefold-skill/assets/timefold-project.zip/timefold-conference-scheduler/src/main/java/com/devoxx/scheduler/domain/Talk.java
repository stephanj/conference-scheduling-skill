package com.devoxx.scheduler.domain;

import ai.timefold.solver.core.api.domain.entity.PlanningEntity;
import ai.timefold.solver.core.api.domain.lookup.PlanningId;
import ai.timefold.solver.core.api.domain.variable.PlanningVariable;

import java.util.HashSet;
import java.util.Set;

/**
 * A conference talk that needs to be scheduled.
 * This is a planning entity - TimeFold will assign timeslot and room.
 */
@PlanningEntity
public class Talk {

    @PlanningId
    private String id;
    private String title;
    private String summary;
    private String trackName;
    private AudienceLevel audienceLevel;
    private String speakerNames;
    
    // Educational flow score (0-100) - computed by AI analysis of summaries
    // Higher score = should come earlier in the day for this track
    private int flowOrder;

    // Speaker availability - which days the speaker(s) can present
    // Empty set means available all days
    private Set<Integer> availableDays = new HashSet<>();
    private String availableDaysRaw; // Original string from CSV (e.g., "Monday,Tuesday" or "1,2,3")

    // Planning variables - assigned by solver
    @PlanningVariable
    private Timeslot timeslot;
    
    @PlanningVariable
    private Room room;

    public Talk() {
    }

    public Talk(String id, String title, String summary, String trackName, 
                AudienceLevel audienceLevel, String speakerNames) {
        this.id = id;
        this.title = title;
        this.summary = summary;
        this.trackName = trackName;
        this.audienceLevel = audienceLevel;
        this.speakerNames = speakerNames;
        this.flowOrder = audienceLevel.getDefaultFlowOrder();
    }

    /**
     * Check if speaker is available on the given day.
     * Returns true if no availability restrictions or if day is in available set.
     */
    public boolean isAvailableOn(int dayIndex) {
        if (availableDays == null || availableDays.isEmpty()) {
            return true; // No restrictions = available all days
        }
        return availableDays.contains(dayIndex);
    }

    /**
     * Check if speaker is available for the assigned timeslot.
     */
    public boolean isAvailableForTimeslot() {
        if (timeslot == null) return true;
        return isAvailableOn(timeslot.getDayIndex());
    }

    /**
     * Parse availability days from CSV string.
     * Supports formats: "1,2,3", "Monday,Tuesday", "Day 1,Day 2"
     */
    public void parseAvailableDays(String daysString, java.util.List<String> allDayNames) {
        this.availableDaysRaw = daysString;
        if (daysString == null || daysString.isBlank()) {
            return; // Available all days
        }

        String[] parts = daysString.split("[,;]");
        for (String part : parts) {
            String day = part.trim().toLowerCase();
            if (day.isEmpty()) continue;

            // Try numeric
            try {
                int dayNum = Integer.parseInt(day);
                availableDays.add(dayNum - 1); // Convert 1-based to 0-based
                continue;
            } catch (NumberFormatException ignored) {}

            // Try matching day names
            for (int i = 0; i < allDayNames.size(); i++) {
                String dayName = allDayNames.get(i).toLowerCase();
                if (dayName.contains(day) || day.contains(dayName) ||
                    day.equals("day " + (i + 1)) || day.equals("d" + (i + 1))) {
                    availableDays.add(i);
                    break;
                }
            }
        }
    }

    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getSummary() { return summary; }
    public void setSummary(String summary) { this.summary = summary; }

    public String getTrackName() { return trackName; }
    public void setTrackName(String trackName) { this.trackName = trackName; }

    public AudienceLevel getAudienceLevel() { return audienceLevel; }
    public void setAudienceLevel(AudienceLevel audienceLevel) { this.audienceLevel = audienceLevel; }

    public String getSpeakerNames() { return speakerNames; }
    public void setSpeakerNames(String speakerNames) { this.speakerNames = speakerNames; }

    public int getFlowOrder() { return flowOrder; }
    public void setFlowOrder(int flowOrder) { this.flowOrder = flowOrder; }

    public Set<Integer> getAvailableDays() { return availableDays; }
    public void setAvailableDays(Set<Integer> availableDays) { this.availableDays = availableDays; }

    public String getAvailableDaysRaw() { return availableDaysRaw; }
    public void setAvailableDaysRaw(String availableDaysRaw) { this.availableDaysRaw = availableDaysRaw; }

    public Timeslot getTimeslot() { return timeslot; }
    public void setTimeslot(Timeslot timeslot) { this.timeslot = timeslot; }

    public Room getRoom() { return room; }
    public void setRoom(Room room) { this.room = room; }

    @Override
    public String toString() {
        return id + ": " + title;
    }
}
