package com.devoxx.scheduler.domain;

import ai.timefold.solver.core.api.domain.solution.PlanningEntityCollectionProperty;
import ai.timefold.solver.core.api.domain.solution.PlanningScore;
import ai.timefold.solver.core.api.domain.solution.PlanningSolution;
import ai.timefold.solver.core.api.domain.solution.ProblemFactCollectionProperty;
import ai.timefold.solver.core.api.domain.valuerange.ValueRangeProvider;
import ai.timefold.solver.core.api.score.buildin.hardsoft.HardSoftScore;

import java.util.List;

/**
 * The planning solution - represents the entire conference schedule.
 */
@PlanningSolution
public class ConferenceSchedule {

    @ProblemFactCollectionProperty
    @ValueRangeProvider
    private List<Timeslot> timeslots;

    @ProblemFactCollectionProperty
    @ValueRangeProvider
    private List<Room> rooms;

    @PlanningEntityCollectionProperty
    private List<Talk> talks;

    @PlanningScore
    private HardSoftScore score;

    public ConferenceSchedule() {
    }

    public ConferenceSchedule(List<Timeslot> timeslots, List<Room> rooms, List<Talk> talks) {
        this.timeslots = timeslots;
        this.rooms = rooms;
        this.talks = talks;
    }

    // Getters and setters
    public List<Timeslot> getTimeslots() { return timeslots; }
    public void setTimeslots(List<Timeslot> timeslots) { this.timeslots = timeslots; }

    public List<Room> getRooms() { return rooms; }
    public void setRooms(List<Room> rooms) { this.rooms = rooms; }

    public List<Talk> getTalks() { return talks; }
    public void setTalks(List<Talk> talks) { this.talks = talks; }

    public HardSoftScore getScore() { return score; }
    public void setScore(HardSoftScore score) { this.score = score; }
}
