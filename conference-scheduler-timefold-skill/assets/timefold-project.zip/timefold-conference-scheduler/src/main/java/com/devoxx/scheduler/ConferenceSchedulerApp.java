package com.devoxx.scheduler;

import ai.timefold.solver.core.api.solver.Solver;
import ai.timefold.solver.core.api.solver.SolverFactory;
import ai.timefold.solver.core.config.solver.SolverConfig;
import ai.timefold.solver.core.config.solver.termination.TerminationConfig;
import com.devoxx.scheduler.domain.ConferenceSchedule;
import com.devoxx.scheduler.domain.Timeslot;
import com.devoxx.scheduler.io.CsvDataReader;
import com.devoxx.scheduler.io.ScheduleWriter;
import com.devoxx.scheduler.solver.ConferenceConstraintProvider;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.*;

/**
 * Main application for conference scheduling.
 * 
 * Usage: java -jar conference-scheduler.jar <schedule.csv> <talks.csv> [output.csv] [--time-limit=30s]
 * 
 * The solver will find an optimal schedule respecting all constraints.
 * Supports both single-day and multi-day conferences.
 */
public class ConferenceSchedulerApp {

    private static final Duration DEFAULT_TIME_LIMIT = Duration.ofSeconds(30);

    public static void main(String[] args) {
        if (args.length < 2) {
            printUsage();
            System.exit(1);
        }

        Path schedulePath = Paths.get(args[0]);
        Path talksPath = Paths.get(args[1]);
        Path outputPath = args.length > 2 && !args[2].startsWith("--") 
            ? Paths.get(args[2]) 
            : Paths.get("schedule_output.csv");
        
        Duration timeLimit = parseTimeLimit(args);

        try {
            ConferenceSchedulerApp app = new ConferenceSchedulerApp();
            app.run(schedulePath, talksPath, outputPath, timeLimit);
        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        }
    }

    public void run(Path schedulePath, Path talksPath, Path outputPath, Duration timeLimit) throws Exception {
        System.out.println("=".repeat(60));
        System.out.println("CONFERENCE SCHEDULER - Powered by TimeFold");
        System.out.println("=".repeat(60));
        
        // Read input data
        System.out.println("\n📖 Reading input files...");
        CsvDataReader reader = new CsvDataReader();
        ConferenceSchedule problem = reader.readProblem(schedulePath, talksPath);
        
        // Count days
        long numDays = problem.getTimeslots().stream()
            .map(Timeslot::getDayIndex)
            .distinct()
            .count();
        
        System.out.printf("   - Days: %d%s%n", numDays, 
            reader.isMultiDay() ? " (" + String.join(", ", reader.getDetectedDayNames()) + ")" : "");
        System.out.printf("   - Timeslots: %d%n", problem.getTimeslots().size());
        System.out.printf("   - Rooms: %d%n", problem.getRooms().size());
        System.out.printf("   - Talks: %d%n", problem.getTalks().size());
        System.out.printf("   - Unique tracks: %d%n", 
            problem.getTalks().stream().map(t -> t.getTrackName()).distinct().count());
        
        // Show speaker availability info
        long talksWithAvailability = problem.getTalks().stream()
            .filter(t -> !t.getAvailableDays().isEmpty())
            .count();
        if (talksWithAvailability > 0) {
            System.out.printf("   - Talks with speaker availability constraints: %d%n", talksWithAvailability);
        }

        // Validate capacity
        int capacity = problem.getTimeslots().size() * problem.getRooms().size();
        if (problem.getTalks().size() > capacity) {
            System.err.printf("⚠️  Warning: More talks (%d) than available slots (%d)%n", 
                problem.getTalks().size(), capacity);
        }

        // Configure solver
        System.out.printf("%n⏱️  Solving with time limit: %s%n", formatDuration(timeLimit));
        
        SolverFactory<ConferenceSchedule> solverFactory = SolverFactory.create(
            new SolverConfig()
                .withSolutionClass(ConferenceSchedule.class)
                .withEntityClasses(com.devoxx.scheduler.domain.Talk.class)
                .withConstraintProviderClass(ConferenceConstraintProvider.class)
                .withTerminationConfig(new TerminationConfig()
                    .withSpentLimit(timeLimit))
        );

        // Solve
        Solver<ConferenceSchedule> solver = solverFactory.buildSolver();
        
        solver.addEventListener(event -> {
            System.out.printf("   New best score: %s%n", event.getNewBestScore());
        });

        ConferenceSchedule solution = solver.solve(problem);

        // Output results
        System.out.println("\n✅ Solving complete!");
        System.out.println("   Final score: " + solution.getScore());

        ScheduleWriter writer = new ScheduleWriter();
        
        // Print to console
        writer.printSchedule(solution);
        
        // Write CSV
        writer.writeCsv(solution, outputPath);
        System.out.println("\n📄 Schedule written to: " + outputPath);
        
        // Write Markdown
        Path mdPath = Paths.get(outputPath.toString().replace(".csv", ".md"));
        java.nio.file.Files.writeString(mdPath, writer.toMarkdown(solution));
        System.out.println("📄 Markdown written to: " + mdPath);

        // Summary
        printConstraintViolations(solution);
    }

    private void printConstraintViolations(ConferenceSchedule solution) {
        if (solution.getScore().hardScore() < 0) {
            System.out.println("\n⚠️  HARD CONSTRAINT VIOLATIONS:");
            System.out.println("   The schedule has " + Math.abs(solution.getScore().hardScore()) 
                + " hard constraint violation(s).");
            System.out.println("   Consider increasing the time limit or reviewing the input data.");
        }
        
        if (solution.getScore().softScore() < 0) {
            System.out.println("\n💡 SOFT CONSTRAINT NOTES:");
            System.out.println("   Educational flow optimizations applied: " 
                + Math.abs(solution.getScore().softScore()) + " soft penalty points.");
        }
    }

    private static Duration parseTimeLimit(String[] args) {
        for (String arg : args) {
            if (arg.startsWith("--time-limit=")) {
                String value = arg.substring("--time-limit=".length());
                if (value.endsWith("s")) {
                    return Duration.ofSeconds(Long.parseLong(value.replace("s", "")));
                } else if (value.endsWith("m")) {
                    return Duration.ofMinutes(Long.parseLong(value.replace("m", "")));
                }
            }
        }
        return DEFAULT_TIME_LIMIT;
    }

    private static String formatDuration(Duration duration) {
        long seconds = duration.getSeconds();
        if (seconds < 60) return seconds + " seconds";
        return (seconds / 60) + " minutes";
    }

    private static void printUsage() {
        System.out.println("Conference Scheduler - TimeFold-powered scheduling");
        System.out.println();
        System.out.println("Usage:");
        System.out.println("  java -jar conference-scheduler.jar <schedule.csv> <talks.csv> [output.csv] [options]");
        System.out.println();
        System.out.println("Arguments:");
        System.out.println("  schedule.csv   CSV file with timeslots and rooms");
        System.out.println("  talks.csv      CSV file with talk details");
        System.out.println("  output.csv     Output file (default: schedule_output.csv)");
        System.out.println();
        System.out.println("Options:");
        System.out.println("  --time-limit=30s   Solver time limit (e.g., 30s, 5m)");
        System.out.println();
        System.out.println("Expected CSV formats:");
        System.out.println();
        System.out.println("Single-day schedule CSV:");
        System.out.println("  \"from hour\";\"to hour\";\"session type\";\"room name\"");
        System.out.println("  \"10:35\";\"11:20\";Conference;Room 2");
        System.out.println();
        System.out.println("Multi-day schedule CSV:");
        System.out.println("  \"day\";\"from hour\";\"to hour\";\"session type\";\"room name\"");
        System.out.println("  \"Wednesday\";\"10:35\";\"11:20\";Conference;Room 2");
        System.out.println("  \"Thursday\";\"09:00\";\"09:45\";Conference;Room 1");
        System.out.println();
        System.out.println("Talks CSV:");
        System.out.println("  \"Talk ID\";\"Talk Title\";\"Audience Level\";\"Talk Summary\";\"Track Name\";");
        System.out.println("  \"Speaker Availability days\";\"Available from\";\"Available to\";\"Speaker names\"");
        System.out.println();
        System.out.println("Speaker Availability formats: \"Wednesday,Thursday\", \"1,2,3\", \"Day 1,Day 2\"");
    }
}
