package com.devoxx.scheduler.domain;

import ai.timefold.solver.core.api.domain.lookup.PlanningId;

/**
 * A room where talks can be held.
 */
public class Room {

    @PlanningId
    private String name;
    private int capacity;

    public Room() {
    }

    public Room(String name) {
        this(name, 0);
    }

    public Room(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Room room = (Room) o;
        return name.equals(room.name);
    }

    @Override
    public int hashCode() {
        return name.hashCode();
    }

    @Override
    public String toString() {
        return name;
    }
}
